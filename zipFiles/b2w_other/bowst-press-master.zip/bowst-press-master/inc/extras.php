<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package bowst-press
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function bowst_press_body_classes( $classes ) {
	// Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}
add_filter( 'body_class', 'bowst_press_body_classes' );

/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function bowst_press_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
	}
}
add_action( 'wp_head', 'bowst_press_pingback_header' );

/**
 * Wrap embedded media so we can make it responsive.
 */
function bowst_press_oembed_html( $html, $url, $attr, $post_id ) {
	return '<div class="entry-oembed">' . $html . '</div>';
}
add_filter( 'embed_oembed_html', 'bowst_press_oembed_html', 99, 4 );

/**
 * Keep Yoast SEO metabox on the bottom.
 */
function bowst_press_tame_yoast_metabox() {
	return 'low';
}
add_filter( 'wpseo_metabox_prio', 'bowst_press_tame_yoast_metabox' );
