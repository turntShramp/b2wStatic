jQuery(document).ready(function($){

	/* Custom JS
	   Feel free to break into separate files if individual functions grow to excessive sizes.
	   Gulp will concatenate and minify separate files automatically. 
	*/

});